﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;

namespace TTC_GS_GUI.UserControles
{
    public partial class Controller : UserControl
    {

        public Controller()
        {
            InitializeComponent();
        }

        private void trackAltitudeValue_Scroll(object sender, EventArgs e)
        {
            UpdateAltitudeGaugeParams();
        }

        private void trackAirSpeedValue_Scroll(object sender, EventArgs e)
        {
            UpdateAltitudeGaugeParams();
        }

        void UpdateAltitudeGaugeParams()
        {
            IPrimaryFlightDisplay pfd = pfdWidget1 as IPrimaryFlightDisplay;

            pfd.Altitude.Value = trackAltitudeValue.Value;
            pfd.AirSpeed.Value = trackAirSpeedValue.Value;

            pfdWidget1.Redraw();
        }

        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
        //    // 
        //    // Controller
        //    // 
        //    this.Name = "Controller";
        //    this.ResumeLayout(false);

        //}

        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
        //    // 
        //    // Controller
        //    // 
        //    this.Name = "Controller";
        //    this.ResumeLayout(false);

        //}



        //private void MouseStick_MouseDoubleClick(object sender, MouseEventArgs e)
        //{
        //    try
        //    {
        //        string move = ParseMoveInfo(txtMove.Text);
        //        txtCommand.Text = move;
        //        InsertLogLine("Move: " + txtMove.Text + ", Command: " + move, Color.LightBlue);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message, "Exception Happen");
        //    }
        //}


        //private string ParseMoveInfo(string move)
        //{
        //    string[] info = move.Split(' ');
        //    int upDegree = 0, downDegree = 0, rigthDegree = 0, leftDegree = 0, speed = 0;

        //    if(info[0] != "") speed = 1;

        //    if(info.Length >= 2)
        //    {
        //        string die = info[1];

        //        if (die.Equals("E")) { upDegree = 135; downDegree = 45; rigthDegree = 45; leftDegree = 135; }
        //        else if (die.Equals("SE")) { upDegree = 90; downDegree = 45; rigthDegree = 45; leftDegree = 135; }
        //        else if (die.Equals("S")) { upDegree = 45; downDegree = 135; rigthDegree = 45; leftDegree = 135; }
        //        else if (die.Equals("SW")) { upDegree = 45; downDegree = 135; rigthDegree = 135; leftDegree = 90; }
        //        else if (die.Equals("W")) { upDegree = 45; downDegree = 135; rigthDegree = 135; leftDegree = 45; }
        //        else if (die.Equals("NW")) { upDegree = 135; downDegree = 90; rigthDegree = 135; leftDegree = 45; }
        //        else if (die.Equals("N")) { upDegree = 135; downDegree = 45; rigthDegree = 135; leftDegree = 45; }
        //        else if (die.Equals("NE")) { upDegree = 135; downDegree = 45; rigthDegree = 90; leftDegree = 45; }
        //    }

        //    return (upDegree + "," + downDegree + "," + rigthDegree + "," + leftDegree + "," + speed);
        //}



        //private void trackAltitudeValue_MouseUp(object sender, MouseEventArgs e)
        //{
        //    InsertLogLine("Altitute changed to: " + trackAltitudeValue.Value, Color.LawnGreen);
        //}

    }
}
