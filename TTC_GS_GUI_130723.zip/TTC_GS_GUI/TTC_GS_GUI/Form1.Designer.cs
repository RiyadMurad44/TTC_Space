﻿namespace TTC_GS_GUI
{
    partial class ttcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ttcForm));
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label30 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Gyro = new System.Windows.Forms.Button();
            this.Stop = new System.Windows.Forms.Button();
            this.battery_voltage = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.current_value = new System.Windows.Forms.TextBox();
            this.Start = new System.Windows.Forms.Button();
            this.sun_exposure = new System.Windows.Forms.TextBox();
            this.Ports = new System.Windows.Forms.Label();
            this.acceleration_x = new System.Windows.Forms.TextBox();
            this.AvailablePorts = new System.Windows.Forms.ComboBox();
            this.acceleration_y = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.acceleration_z = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.angular_rate_phi = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.angular_rate_theta = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.angular_rate_psi = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.angles_phi = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.angles_theta = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.angles_psi = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.position_x = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.position_y = new System.Windows.Forms.TextBox();
            this.valve_4 = new System.Windows.Forms.TextBox();
            this.position_z = new System.Windows.Forms.TextBox();
            this.valve_3 = new System.Windows.Forms.TextBox();
            this.valve_1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.valve_2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.radio_status = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cube_sat_id = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.software_version = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.battery_status = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.temperature = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.ReceivedBytesThreshold = 2;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort_DataReceived);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Location = new System.Drawing.Point(240, 29);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(351, 37);
            this.label30.TabIndex = 61;
            this.label30.Text = "AS-COMSAT_1 TT&&C";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(26, 14);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(112, 69);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 64;
            this.pictureBox2.TabStop = false;
            // 
            // Gyro
            // 
            this.Gyro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gyro.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Gyro.Location = new System.Drawing.Point(62, 325);
            this.Gyro.Name = "Gyro";
            this.Gyro.Size = new System.Drawing.Size(73, 28);
            this.Gyro.TabIndex = 187;
            this.Gyro.Text = "Gyro";
            this.Gyro.UseVisualStyleBackColor = true;
            this.Gyro.Click += new System.EventHandler(this.Gyro_Click);
            // 
            // Stop
            // 
            this.Stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stop.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Stop.Location = new System.Drawing.Point(62, 272);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(73, 28);
            this.Stop.TabIndex = 186;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            this.Stop.Click += new System.EventHandler(this.Stop_Click);
            // 
            // battery_voltage
            // 
            this.battery_voltage.Enabled = false;
            this.battery_voltage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.battery_voltage.Location = new System.Drawing.Point(40, 58);
            this.battery_voltage.Margin = new System.Windows.Forms.Padding(2);
            this.battery_voltage.Multiline = true;
            this.battery_voltage.Name = "battery_voltage";
            this.battery_voltage.Size = new System.Drawing.Size(89, 30);
            this.battery_voltage.TabIndex = 128;
            this.battery_voltage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(32, 35);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(136, 119);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 184;
            this.pictureBox1.TabStop = false;
            // 
            // current_value
            // 
            this.current_value.Enabled = false;
            this.current_value.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current_value.Location = new System.Drawing.Point(163, 58);
            this.current_value.Margin = new System.Windows.Forms.Padding(2);
            this.current_value.Multiline = true;
            this.current_value.Name = "current_value";
            this.current_value.Size = new System.Drawing.Size(89, 30);
            this.current_value.TabIndex = 129;
            this.current_value.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Start
            // 
            this.Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Start.Location = new System.Drawing.Point(62, 227);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(73, 28);
            this.Start.TabIndex = 183;
            this.Start.Text = "Start";
            this.Start.UseVisualStyleBackColor = true;
            this.Start.Click += new System.EventHandler(this.Start_Click);
            // 
            // sun_exposure
            // 
            this.sun_exposure.Enabled = false;
            this.sun_exposure.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sun_exposure.Location = new System.Drawing.Point(290, 58);
            this.sun_exposure.Margin = new System.Windows.Forms.Padding(2);
            this.sun_exposure.Multiline = true;
            this.sun_exposure.Name = "sun_exposure";
            this.sun_exposure.Size = new System.Drawing.Size(89, 30);
            this.sun_exposure.TabIndex = 130;
            this.sun_exposure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Ports
            // 
            this.Ports.AutoSize = true;
            this.Ports.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ports.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Ports.Location = new System.Drawing.Point(117, 283);
            this.Ports.Name = "Ports";
            this.Ports.Size = new System.Drawing.Size(51, 20);
            this.Ports.TabIndex = 182;
            this.Ports.Text = "Ports";
            // 
            // acceleration_x
            // 
            this.acceleration_x.Enabled = false;
            this.acceleration_x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acceleration_x.Location = new System.Drawing.Point(40, 138);
            this.acceleration_x.Margin = new System.Windows.Forms.Padding(2);
            this.acceleration_x.Multiline = true;
            this.acceleration_x.Name = "acceleration_x";
            this.acceleration_x.Size = new System.Drawing.Size(89, 30);
            this.acceleration_x.TabIndex = 131;
            this.acceleration_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AvailablePorts
            // 
            this.AvailablePorts.FormattingEnabled = true;
            this.AvailablePorts.Location = new System.Drawing.Point(32, 201);
            this.AvailablePorts.Name = "AvailablePorts";
            this.AvailablePorts.Size = new System.Drawing.Size(137, 21);
            this.AvailablePorts.TabIndex = 181;
            // 
            // acceleration_y
            // 
            this.acceleration_y.Enabled = false;
            this.acceleration_y.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acceleration_y.Location = new System.Drawing.Point(163, 138);
            this.acceleration_y.Margin = new System.Windows.Forms.Padding(2);
            this.acceleration_y.Multiline = true;
            this.acceleration_y.Name = "acceleration_y";
            this.acceleration_y.Size = new System.Drawing.Size(89, 30);
            this.acceleration_y.TabIndex = 132;
            this.acceleration_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.Window;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Teal;
            this.label29.Location = new System.Drawing.Point(428, 290);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 17);
            this.label29.TabIndex = 180;
            this.label29.Text = "Battery Status";
            // 
            // acceleration_z
            // 
            this.acceleration_z.Enabled = false;
            this.acceleration_z.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acceleration_z.Location = new System.Drawing.Point(290, 138);
            this.acceleration_z.Margin = new System.Windows.Forms.Padding(2);
            this.acceleration_z.Multiline = true;
            this.acceleration_z.Name = "acceleration_z";
            this.acceleration_z.Size = new System.Drawing.Size(89, 30);
            this.acceleration_z.TabIndex = 133;
            this.acceleration_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.Window;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Teal;
            this.label28.Location = new System.Drawing.Point(425, 197);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(95, 17);
            this.label28.TabIndex = 179;
            this.label28.Text = "CubeSAT ID";
            // 
            // angular_rate_phi
            // 
            this.angular_rate_phi.Enabled = false;
            this.angular_rate_phi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angular_rate_phi.Location = new System.Drawing.Point(40, 225);
            this.angular_rate_phi.Margin = new System.Windows.Forms.Padding(2);
            this.angular_rate_phi.Multiline = true;
            this.angular_rate_phi.Name = "angular_rate_phi";
            this.angular_rate_phi.Size = new System.Drawing.Size(89, 30);
            this.angular_rate_phi.TabIndex = 134;
            this.angular_rate_phi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.Window;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Teal;
            this.label27.Location = new System.Drawing.Point(425, 111);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(101, 17);
            this.label27.TabIndex = 178;
            this.label27.Text = "Temperature";
            // 
            // angular_rate_theta
            // 
            this.angular_rate_theta.Enabled = false;
            this.angular_rate_theta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angular_rate_theta.Location = new System.Drawing.Point(163, 225);
            this.angular_rate_theta.Margin = new System.Windows.Forms.Padding(2);
            this.angular_rate_theta.Multiline = true;
            this.angular_rate_theta.Name = "angular_rate_theta";
            this.angular_rate_theta.Size = new System.Drawing.Size(89, 30);
            this.angular_rate_theta.TabIndex = 135;
            this.angular_rate_theta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Window;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Teal;
            this.label26.Location = new System.Drawing.Point(425, 32);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(131, 17);
            this.label26.TabIndex = 177;
            this.label26.Text = "Software Version";
            // 
            // angular_rate_psi
            // 
            this.angular_rate_psi.Enabled = false;
            this.angular_rate_psi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angular_rate_psi.Location = new System.Drawing.Point(290, 225);
            this.angular_rate_psi.Margin = new System.Windows.Forms.Padding(2);
            this.angular_rate_psi.Multiline = true;
            this.angular_rate_psi.Name = "angular_rate_psi";
            this.angular_rate_psi.Size = new System.Drawing.Size(89, 30);
            this.angular_rate_psi.TabIndex = 136;
            this.angular_rate_psi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.Window;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Teal;
            this.label25.Location = new System.Drawing.Point(430, 389);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(101, 17);
            this.label25.TabIndex = 176;
            this.label25.Text = "Radio Status";
            // 
            // angles_phi
            // 
            this.angles_phi.Enabled = false;
            this.angles_phi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angles_phi.Location = new System.Drawing.Point(40, 323);
            this.angles_phi.Margin = new System.Windows.Forms.Padding(2);
            this.angles_phi.Multiline = true;
            this.angles_phi.Name = "angles_phi";
            this.angles_phi.Size = new System.Drawing.Size(89, 30);
            this.angles_phi.TabIndex = 137;
            this.angles_phi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.Window;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Teal;
            this.label24.Location = new System.Drawing.Point(468, 532);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 17);
            this.label24.TabIndex = 175;
            this.label24.Text = "4";
            // 
            // angles_theta
            // 
            this.angles_theta.Enabled = false;
            this.angles_theta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angles_theta.Location = new System.Drawing.Point(163, 323);
            this.angles_theta.Margin = new System.Windows.Forms.Padding(2);
            this.angles_theta.Multiline = true;
            this.angles_theta.Name = "angles_theta";
            this.angles_theta.Size = new System.Drawing.Size(89, 30);
            this.angles_theta.TabIndex = 138;
            this.angles_theta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.Window;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Teal;
            this.label21.Location = new System.Drawing.Point(332, 532);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(17, 17);
            this.label21.TabIndex = 174;
            this.label21.Text = "3";
            // 
            // angles_psi
            // 
            this.angles_psi.Enabled = false;
            this.angles_psi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angles_psi.Location = new System.Drawing.Point(290, 323);
            this.angles_psi.Margin = new System.Windows.Forms.Padding(2);
            this.angles_psi.Multiline = true;
            this.angles_psi.Name = "angles_psi";
            this.angles_psi.Size = new System.Drawing.Size(89, 30);
            this.angles_psi.TabIndex = 139;
            this.angles_psi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.Window;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Teal;
            this.label22.Location = new System.Drawing.Point(204, 532);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 17);
            this.label22.TabIndex = 173;
            this.label22.Text = "2";
            // 
            // position_x
            // 
            this.position_x.Enabled = false;
            this.position_x.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.position_x.Location = new System.Drawing.Point(40, 415);
            this.position_x.Margin = new System.Windows.Forms.Padding(2);
            this.position_x.Multiline = true;
            this.position_x.Name = "position_x";
            this.position_x.Size = new System.Drawing.Size(89, 30);
            this.position_x.TabIndex = 140;
            this.position_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.Window;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Teal;
            this.label23.Location = new System.Drawing.Point(78, 532);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 17);
            this.label23.TabIndex = 172;
            this.label23.Text = "1";
            // 
            // position_y
            // 
            this.position_y.Enabled = false;
            this.position_y.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.position_y.Location = new System.Drawing.Point(163, 415);
            this.position_y.Margin = new System.Windows.Forms.Padding(2);
            this.position_y.Multiline = true;
            this.position_y.Name = "position_y";
            this.position_y.Size = new System.Drawing.Size(89, 30);
            this.position_y.TabIndex = 141;
            this.position_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // valve_4
            // 
            this.valve_4.Enabled = false;
            this.valve_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valve_4.Location = new System.Drawing.Point(428, 501);
            this.valve_4.Margin = new System.Windows.Forms.Padding(2);
            this.valve_4.Multiline = true;
            this.valve_4.Name = "valve_4";
            this.valve_4.Size = new System.Drawing.Size(89, 30);
            this.valve_4.TabIndex = 171;
            this.valve_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // position_z
            // 
            this.position_z.Enabled = false;
            this.position_z.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.position_z.Location = new System.Drawing.Point(290, 415);
            this.position_z.Margin = new System.Windows.Forms.Padding(2);
            this.position_z.Multiline = true;
            this.position_z.Name = "position_z";
            this.position_z.Size = new System.Drawing.Size(89, 30);
            this.position_z.TabIndex = 142;
            this.position_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // valve_3
            // 
            this.valve_3.Enabled = false;
            this.valve_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valve_3.Location = new System.Drawing.Point(290, 501);
            this.valve_3.Margin = new System.Windows.Forms.Padding(2);
            this.valve_3.Multiline = true;
            this.valve_3.Name = "valve_3";
            this.valve_3.Size = new System.Drawing.Size(89, 30);
            this.valve_3.TabIndex = 170;
            this.valve_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // valve_1
            // 
            this.valve_1.Enabled = false;
            this.valve_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valve_1.Location = new System.Drawing.Point(40, 501);
            this.valve_1.Margin = new System.Windows.Forms.Padding(2);
            this.valve_1.Multiline = true;
            this.valve_1.Name = "valve_1";
            this.valve_1.Size = new System.Drawing.Size(89, 30);
            this.valve_1.TabIndex = 143;
            this.valve_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.Window;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(328, 448);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 17);
            this.label18.TabIndex = 169;
            this.label18.Text = "Z";
            // 
            // valve_2
            // 
            this.valve_2.Enabled = false;
            this.valve_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.valve_2.Location = new System.Drawing.Point(163, 501);
            this.valve_2.Margin = new System.Windows.Forms.Padding(2);
            this.valve_2.Multiline = true;
            this.valve_2.Name = "valve_2";
            this.valve_2.Size = new System.Drawing.Size(89, 30);
            this.valve_2.TabIndex = 144;
            this.valve_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.Window;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Teal;
            this.label19.Location = new System.Drawing.Point(196, 448);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 17);
            this.label19.TabIndex = 168;
            this.label19.Text = "Y";
            // 
            // radio_status
            // 
            this.radio_status.Enabled = false;
            this.radio_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_status.Location = new System.Drawing.Point(428, 415);
            this.radio_status.Margin = new System.Windows.Forms.Padding(2);
            this.radio_status.Multiline = true;
            this.radio_status.Name = "radio_status";
            this.radio_status.Size = new System.Drawing.Size(89, 30);
            this.radio_status.TabIndex = 145;
            this.radio_status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.Window;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Teal;
            this.label20.Location = new System.Drawing.Point(70, 448);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 17);
            this.label20.TabIndex = 167;
            this.label20.Text = "X";
            // 
            // cube_sat_id
            // 
            this.cube_sat_id.Enabled = false;
            this.cube_sat_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cube_sat_id.Location = new System.Drawing.Point(428, 225);
            this.cube_sat_id.Margin = new System.Windows.Forms.Padding(2);
            this.cube_sat_id.Multiline = true;
            this.cube_sat_id.Name = "cube_sat_id";
            this.cube_sat_id.Size = new System.Drawing.Size(89, 30);
            this.cube_sat_id.TabIndex = 146;
            this.cube_sat_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.Window;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Teal;
            this.label15.Location = new System.Drawing.Point(320, 355);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 17);
            this.label15.TabIndex = 166;
            this.label15.Text = "Psi";
            // 
            // software_version
            // 
            this.software_version.Enabled = false;
            this.software_version.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.software_version.Location = new System.Drawing.Point(428, 58);
            this.software_version.Margin = new System.Windows.Forms.Padding(2);
            this.software_version.Multiline = true;
            this.software_version.Name = "software_version";
            this.software_version.Size = new System.Drawing.Size(89, 30);
            this.software_version.TabIndex = 147;
            this.software_version.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.Window;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Teal;
            this.label16.Location = new System.Drawing.Point(184, 355);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 17);
            this.label16.TabIndex = 165;
            this.label16.Text = "Theta";
            // 
            // battery_status
            // 
            this.battery_status.Enabled = false;
            this.battery_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.battery_status.Location = new System.Drawing.Point(428, 323);
            this.battery_status.Margin = new System.Windows.Forms.Padding(2);
            this.battery_status.Multiline = true;
            this.battery_status.Name = "battery_status";
            this.battery_status.Size = new System.Drawing.Size(89, 30);
            this.battery_status.TabIndex = 148;
            this.battery_status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.Window;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(67, 355);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 17);
            this.label17.TabIndex = 164;
            this.label17.Text = "Phi";
            // 
            // temperature
            // 
            this.temperature.Enabled = false;
            this.temperature.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.temperature.Location = new System.Drawing.Point(428, 138);
            this.temperature.Margin = new System.Windows.Forms.Padding(2);
            this.temperature.Multiline = true;
            this.temperature.Name = "temperature";
            this.temperature.Size = new System.Drawing.Size(89, 30);
            this.temperature.TabIndex = 149;
            this.temperature.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Window;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(320, 258);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 17);
            this.label12.TabIndex = 163;
            this.label12.Text = "Psi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(37, 111);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 150;
            this.label1.Text = "Acceleration";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Window;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(184, 258);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 17);
            this.label13.TabIndex = 162;
            this.label13.Text = "Theta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Window;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(37, 197);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 17);
            this.label2.TabIndex = 151;
            this.label2.Text = "Angular Rate";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.Window;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Teal;
            this.label14.Location = new System.Drawing.Point(67, 258);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 17);
            this.label14.TabIndex = 161;
            this.label14.Text = "Phi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(37, 297);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 152;
            this.label3.Text = "Angles";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Window;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Teal;
            this.label11.Location = new System.Drawing.Point(328, 171);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 17);
            this.label11.TabIndex = 160;
            this.label11.Text = "Z";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Window;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(36, 389);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 17);
            this.label4.TabIndex = 153;
            this.label4.Text = "Position";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Window;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(196, 171);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 17);
            this.label10.TabIndex = 159;
            this.label10.Text = "Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Window;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(37, 475);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 154;
            this.label5.Text = "Valve Status";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Window;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(70, 171);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 17);
            this.label9.TabIndex = 158;
            this.label9.Text = "X";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Window;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(37, 32);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 17);
            this.label6.TabIndex = 155;
            this.label6.Text = "Battery Voltage";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Window;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(288, 32);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 157;
            this.label8.Text = "Sun Exposure";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Window;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(160, 32);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 17);
            this.label7.TabIndex = 156;
            this.label7.Text = "Current Value";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.AvailablePorts);
            this.panel1.Controls.Add(this.Start);
            this.panel1.Controls.Add(this.Gyro);
            this.panel1.Controls.Add(this.Stop);
            this.panel1.Location = new System.Drawing.Point(0, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 580);
            this.panel1.TabIndex = 188;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Location = new System.Drawing.Point(0, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(808, 96);
            this.panel2.TabIndex = 189;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Snow;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.battery_voltage);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.current_value);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.sun_exposure);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.acceleration_x);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.acceleration_y);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.acceleration_z);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.angular_rate_phi);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.angular_rate_theta);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.temperature);
            this.panel3.Controls.Add(this.angular_rate_psi);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.battery_status);
            this.panel3.Controls.Add(this.angles_phi);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.software_version);
            this.panel3.Controls.Add(this.angles_theta);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.cube_sat_id);
            this.panel3.Controls.Add(this.angles_psi);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.radio_status);
            this.panel3.Controls.Add(this.position_x);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.valve_2);
            this.panel3.Controls.Add(this.position_y);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.valve_4);
            this.panel3.Controls.Add(this.valve_1);
            this.panel3.Controls.Add(this.position_z);
            this.panel3.Controls.Add(this.valve_3);
            this.panel3.Location = new System.Drawing.Point(225, 103);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(581, 573);
            this.panel3.TabIndex = 190;
            // 
            // ttcForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(821, 685);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Ports);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ttcForm";
            this.Text = "AS-COMSAT_1 TT&C";
            this.Load += new System.EventHandler(this.ttcForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Gyro;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.TextBox battery_voltage;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox current_value;
        private System.Windows.Forms.Button Start;
        private System.Windows.Forms.TextBox sun_exposure;
        private System.Windows.Forms.Label Ports;
        private System.Windows.Forms.TextBox acceleration_x;
        private System.Windows.Forms.ComboBox AvailablePorts;
        private System.Windows.Forms.TextBox acceleration_y;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox acceleration_z;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox angular_rate_phi;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox angular_rate_theta;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox angular_rate_psi;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox angles_phi;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox angles_theta;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox angles_psi;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox position_x;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox position_y;
        private System.Windows.Forms.TextBox valve_4;
        private System.Windows.Forms.TextBox position_z;
        private System.Windows.Forms.TextBox valve_3;
        private System.Windows.Forms.TextBox valve_1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox valve_2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox radio_status;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox cube_sat_id;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox software_version;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox battery_status;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox temperature;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}

