﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TTC_GS_GUI.Indicators;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TTC_GS_GUI
{
    public partial class Gyroscope : Form
    {
        Stateform sf;

        // Load images
        //Bitmap mybitmap1 = new Bitmap(AttitudeIndicator.Properties.Resources.horizon);
        Bitmap mybitmap1 = new Bitmap(@"..\..\gyroscope\horizon3.bmp");
        //Bitmap mybitmap2 = new Bitmap(@"..\..\gyroscope\bording(550).bmp");
        Bitmap mybitmap2 = new Bitmap(@"..\..\gyroscope\bording3.png");
        //Bitmap mybitmap3 = new Bitmap(@"..\..\gyroscope\measurement.png");
        Bitmap mybitmap3 = new Bitmap(@"..\..\gyroscope\center2.bmp");
        Bitmap mybitmap4 = new Bitmap(@"..\..\gyroscope\wings3.png");

        double PitchAngle = 0;
        double RollAngle = 0;
        double YawAngle = 0;

        //Point ptBoule = new Point(-25, -410); //Ground-Sky initial location (Bording 300, 300 width)
        //Point ptHeading = new Point(-592, 150); // Center ticks (Bording 300,300 width)
        //Point ptRotation = new Point(150, 150); // Point of rotation
        Point ptBoule = new Point(-55, -768); //Ground-Sky initial location
        Point ptHeading = new Point(-592, 277); // Center ticks
        Point ptRotation = new Point(275, 275); // Point of rotation

        public Gyroscope(Stateform sf)
        {
            InitializeComponent();
            this.sf = sf;

            // This bit of code (using double buffer) reduces flicker from Refresh commands
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            //////////// END "reduce flicker" code ///////
        }

        private void Gyroscope_Load(object sender, EventArgs e)
        {
            mybitmap2.MakeTransparent(Color.Yellow); // Sets image transparency
            mybitmap3.MakeTransparent(Color.Black); // Sets image transparency
            mybitmap4.MakeTransparent(Color.Yellow); // Sets image transparency
            //UpdateValues();                                                  
        }

        // OnPaint takes care of drawing all graphics to the screen automatically
        protected override void OnPaint(PaintEventArgs paintEvnt)
        {

            // Calling the base class OnPaint
            base.OnPaint(paintEvnt);

            // Clipping mask for Attitude Indicator
            paintEvnt.Graphics.Clip = new Region(new Rectangle(0, 0, 550, 550));
            paintEvnt.Graphics.FillRegion(Brushes.Black, paintEvnt.Graphics.Clip);

            // Make sure lines are drawn smoothly
            paintEvnt.Graphics.SmoothingMode = SmoothingMode.HighQuality;

            // Create the graphics object
            Graphics gfx = paintEvnt.Graphics;

            // Adjust and draw horizon image
            //                 Paint      Image      alphaRot   alphaTrs,ptImg,deltaPx                ptRot      scalefactor
            RotateAndTranslate(paintEvnt, mybitmap1, RollAngle, 0, ptBoule, (double)(7.60 * PitchAngle), ptRotation, 1);
            //RotateAndTranslate(paintEvnt, mybitmap1, RollAngle, 0, ptBoule, (double)(4 * PitchAngle), ptRotation, 1); //deltaPx is multiplied by 4 on bording 300,300

            //                 Paint      Image       yawRot    alphaRot  alphaTrs,ptImg,deltaPx                      ptRot    scalefactor
            RotateAndTranslate2(paintEvnt, mybitmap3, YawAngle, RollAngle, 0, ptHeading, (double)(7.60 * PitchAngle), ptRotation, 1);
            //RotateAndTranslate2(paintEvnt, mybitmap3, YawAngle, RollAngle, 0, ptHeading, (double)(4 * PitchAngle), ptRotation, 1); //deltaPx is multiplied by 4 on bording 300,300

            gfx.DrawImage(mybitmap2, 0, 0); // Draw bording image
            gfx.DrawImage(mybitmap4, 122, 222); // Draw wings image
            //gfx.DrawImage(mybitmap4, 75, 125); // Draw wings image

            ProcessAngles();

        }

        protected void RotateAndTranslate(PaintEventArgs pe, Image img, Double alphaRot, Double alphaTrs, Point ptImg, double deltaPx, Point ptRot, float scaleFactor)
        {
            double beta = 0;
            double d = 0; //distance
            float deltaXRot = 0;
            float deltaYRot = 0;
            float deltaXTrs = 0;
            float deltaYTrs = 0;

            // Rotation
            if (ptImg != ptRot)
            {
                // Internals coeffs
                if (ptRot.X != 0)
                {
                    beta = Math.Atan((double)ptRot.Y / (double)ptRot.X);
                }

                d = Math.Sqrt((ptRot.X * ptRot.X) + (ptRot.Y * ptRot.Y));

                // Computed offset
                deltaXRot = (float)(d * (Math.Cos(alphaRot - beta) - Math.Cos(alphaRot) * Math.Cos(alphaRot + beta) - Math.Sin(alphaRot) * Math.Sin(alphaRot + beta)));
                deltaYRot = (float)(d * (Math.Sin(beta - alphaRot) + Math.Sin(alphaRot) * Math.Cos(alphaRot + beta) - Math.Cos(alphaRot) * Math.Sin(alphaRot + beta)));
            }

            // Translation

            // Computed offset
            deltaXTrs = (float)(deltaPx * (Math.Sin(alphaTrs)));
            deltaYTrs = (float)(-deltaPx * (-Math.Cos(alphaTrs)));

            // Rotate image support
            pe.Graphics.RotateTransform((float)(alphaRot * 180 / Math.PI));

            // Dispay image
            pe.Graphics.DrawImage(img, (ptImg.X + deltaXRot + deltaXTrs) * scaleFactor, (ptImg.Y + deltaYRot + deltaYTrs) * scaleFactor, img.Width * scaleFactor, img.Height * scaleFactor);

            // Put image support as found
            pe.Graphics.RotateTransform((float)(-alphaRot * 180 / Math.PI));
        }

        protected void RotateAndTranslate2(PaintEventArgs pe, Image img, Double yawRot, Double alphaRot, Double alphaTrs, Point ptImg, double deltaPx, Point ptRot, float scaleFactor)
        {
            double beta = 0;            
            double d = 0; //distance
            float deltaXRot = 0;
            float deltaYRot = 0;
            float deltaXTrs = 0;
            float deltaYTrs = 0;

            // Rotation
            if (ptImg != ptRot)
            {
                // Internals coeffs
                if (ptRot.X != 0)
                {
                    beta = Math.Atan((double)ptRot.Y / (double)ptRot.X);
                }

                d = Math.Sqrt((ptRot.X * ptRot.X) + (ptRot.Y * ptRot.Y));

                // Computed offset
                deltaXRot = (float)(d * (Math.Cos(alphaRot - beta) - Math.Cos(alphaRot) * Math.Cos(alphaRot + beta) - Math.Sin(alphaRot) * Math.Sin(alphaRot + beta) + yawRot));
                deltaYRot = (float)(d * (Math.Sin(beta - alphaRot) + Math.Sin(alphaRot) * Math.Cos(alphaRot + beta) - Math.Cos(alphaRot) * Math.Sin(alphaRot + beta)));
            }

            // Translation

            // Computed offset
            deltaXTrs = (float)(deltaPx * (Math.Sin(alphaTrs)));
            deltaYTrs = (float)(-deltaPx * (-Math.Cos(alphaTrs)));

            // Rotate image support
            pe.Graphics.RotateTransform((float)(alphaRot * 180 / Math.PI));

            // Dispay image
            pe.Graphics.DrawImage(img, (ptImg.X + deltaXRot + deltaXTrs) * scaleFactor, (ptImg.Y + deltaYRot + deltaYTrs) * scaleFactor, img.Width * scaleFactor, img.Height * scaleFactor);

            // Put image support as found
            pe.Graphics.RotateTransform((float)(-alphaRot * 180 / Math.PI));
        }      

        private void ProcessAngles()
        {
            PitchAngle = sf.getGyroTheta();
            RollAngle = -1.0 * sf.getGyroPhi() * Math.PI / 180;
            YawAngle = -1.0 * sf.getGyroPsi() * Math.PI / 180;
            if (YawAngle < -Math.PI) YawAngle = YawAngle + Math.PI;

            UpdateValues();

            Invalidate();
        }

        private void UpdateValues()
        {          
            Altitude.Text = sf.getAltitude().ToString();
            altitudeSlider.Value = (int)sf.getAltitude();

            if (sf.getGyroPhi() < 0)
            {
                double z = -(sf.getGyroPhi());
                phiValue.Text = "-" + (int)z;
            }
            else
            {
                phiValue.Text = sf.getGyroPhi().ToString();
                phiSlider.Value = (int)sf.getGyroPhi();
            }

            if (sf.getGyroTheta() < 0)
            {
                double z = -(sf.getGyroTheta());
                thetaValue.Text = "-" + (int)z;
            }
            else
            {
                thetaValue.Text = sf.getGyroTheta().ToString();
                thetaSlider.Value = (int)sf.getGyroTheta();
            }

            if (sf.getGyroPsi() < 0)
            {
                double z = -(sf.getGyroPsi());
                psiValue.Text = "-" + (int)z;
            }
            else
            {
                psiValue.Text = sf.getGyroPsi().ToString();
                psiSlider.Value = (int)sf.getGyroPsi();
            }
        }

        private void Gyroscope_FormClosed(object sender, FormClosedEventArgs e)
        {
            sf.setIsGyroOpened(false);
        }

        private void Altitude_TextChanged(object sender, EventArgs e)
        {
            this.Invalidate();
            this.Refresh();
        }

    }
}
