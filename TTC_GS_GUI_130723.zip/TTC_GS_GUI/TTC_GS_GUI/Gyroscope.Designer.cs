﻿namespace TTC_GS_GUI
{
    partial class Gyroscope
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.altitudeSlider = new System.Windows.Forms.TrackBar();
            this.Altitude = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.psiSlider = new System.Windows.Forms.TrackBar();
            this.thetaSlider = new System.Windows.Forms.TrackBar();
            this.phiSlider = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.phiValue = new System.Windows.Forms.TextBox();
            this.thetaValue = new System.Windows.Forms.TextBox();
            this.psiValue = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.altitudeSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.psiSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thetaSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phiSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // altitudeSlider
            // 
            this.altitudeSlider.BackColor = System.Drawing.Color.White;
            this.altitudeSlider.Enabled = false;
            this.altitudeSlider.Location = new System.Drawing.Point(584, 43);
            this.altitudeSlider.Maximum = 1000;
            this.altitudeSlider.Name = "altitudeSlider";
            this.altitudeSlider.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.altitudeSlider.Size = new System.Drawing.Size(45, 455);
            this.altitudeSlider.TabIndex = 1;
            this.altitudeSlider.TickStyle = System.Windows.Forms.TickStyle.Both;
            // 
            // Altitude
            // 
            this.Altitude.Enabled = false;
            this.Altitude.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Altitude.Location = new System.Drawing.Point(562, 503);
            this.Altitude.Margin = new System.Windows.Forms.Padding(2);
            this.Altitude.Multiline = true;
            this.Altitude.Name = "Altitude";
            this.Altitude.Size = new System.Drawing.Size(89, 45);
            this.Altitude.TabIndex = 148;
            this.Altitude.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Altitude.TextChanged += new System.EventHandler(this.Altitude_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(570, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 24);
            this.label1.TabIndex = 149;
            this.label1.Text = "Altitude";
            // 
            // psiSlider
            // 
            this.psiSlider.BackColor = System.Drawing.Color.White;
            this.psiSlider.Enabled = false;
            this.psiSlider.Location = new System.Drawing.Point(653, 435);
            this.psiSlider.Maximum = 60;
            this.psiSlider.Name = "psiSlider";
            this.psiSlider.Size = new System.Drawing.Size(231, 45);
            this.psiSlider.TabIndex = 151;
            // 
            // thetaSlider
            // 
            this.thetaSlider.BackColor = System.Drawing.Color.White;
            this.thetaSlider.Enabled = false;
            this.thetaSlider.Location = new System.Drawing.Point(653, 287);
            this.thetaSlider.Maximum = 60;
            this.thetaSlider.Name = "thetaSlider";
            this.thetaSlider.Size = new System.Drawing.Size(231, 45);
            this.thetaSlider.TabIndex = 152;
            // 
            // phiSlider
            // 
            this.phiSlider.BackColor = System.Drawing.Color.White;
            this.phiSlider.Enabled = false;
            this.phiSlider.Location = new System.Drawing.Point(653, 139);
            this.phiSlider.Maximum = 60;
            this.phiSlider.Name = "phiSlider";
            this.phiSlider.Size = new System.Drawing.Size(231, 45);
            this.phiSlider.TabIndex = 153;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(660, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 24);
            this.label3.TabIndex = 154;
            this.label3.Text = "Angle Phi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(660, 251);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 24);
            this.label4.TabIndex = 155;
            this.label4.Text = "Angle Theta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(660, 398);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 24);
            this.label5.TabIndex = 156;
            this.label5.Text = "Angle Psi";
            // 
            // phiValue
            // 
            this.phiValue.Enabled = false;
            this.phiValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phiValue.Location = new System.Drawing.Point(889, 139);
            this.phiValue.Margin = new System.Windows.Forms.Padding(2);
            this.phiValue.Multiline = true;
            this.phiValue.Name = "phiValue";
            this.phiValue.Size = new System.Drawing.Size(89, 45);
            this.phiValue.TabIndex = 157;
            this.phiValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thetaValue
            // 
            this.thetaValue.Enabled = false;
            this.thetaValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thetaValue.Location = new System.Drawing.Point(889, 287);
            this.thetaValue.Margin = new System.Windows.Forms.Padding(2);
            this.thetaValue.Multiline = true;
            this.thetaValue.Name = "thetaValue";
            this.thetaValue.Size = new System.Drawing.Size(89, 45);
            this.thetaValue.TabIndex = 158;
            this.thetaValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // psiValue
            // 
            this.psiValue.Enabled = false;
            this.psiValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.psiValue.Location = new System.Drawing.Point(889, 435);
            this.psiValue.Margin = new System.Windows.Forms.Padding(2);
            this.psiValue.Multiline = true;
            this.psiValue.Name = "psiValue";
            this.psiValue.Size = new System.Drawing.Size(89, 45);
            this.psiValue.TabIndex = 159;
            this.psiValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(290, 435);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(89, 45);
            this.textBox1.TabIndex = 168;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(290, 287);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(89, 45);
            this.textBox2.TabIndex = 167;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(290, 139);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(89, 45);
            this.textBox3.TabIndex = 166;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(61, 398);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 24);
            this.label2.TabIndex = 165;
            this.label2.Text = "Angle Psi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(61, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 24);
            this.label6.TabIndex = 164;
            this.label6.Text = "Angle Theta";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(61, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 24);
            this.label7.TabIndex = 163;
            this.label7.Text = "Angle Phi";
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.White;
            this.trackBar1.Location = new System.Drawing.Point(54, 139);
            this.trackBar1.Maximum = 60;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(231, 45);
            this.trackBar1.TabIndex = 162;
            // 
            // trackBar2
            // 
            this.trackBar2.BackColor = System.Drawing.Color.White;
            this.trackBar2.Location = new System.Drawing.Point(54, 287);
            this.trackBar2.Maximum = 60;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(231, 45);
            this.trackBar2.TabIndex = 161;
            // 
            // trackBar3
            // 
            this.trackBar3.BackColor = System.Drawing.Color.White;
            this.trackBar3.Location = new System.Drawing.Point(54, 435);
            this.trackBar3.Maximum = 60;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Size = new System.Drawing.Size(231, 45);
            this.trackBar3.TabIndex = 160;
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(774, 43);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(103, 24);
            this.textBox4.TabIndex = 169;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Teal;
            this.label28.Location = new System.Drawing.Point(660, 43);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 20);
            this.label28.TabIndex = 180;
            this.label28.Text = "CubeSAT ID";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.trackBar1);
            this.panel1.Controls.Add(this.trackBar2);
            this.panel1.Controls.Add(this.trackBar3);
            this.panel1.Location = new System.Drawing.Point(1040, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(425, 614);
            this.panel1.TabIndex = 181;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(139, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(136, 24);
            this.label8.TabIndex = 169;
            this.label8.Text = "Control Panel";
            // 
            // Gyroscope
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1509, 611);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.psiValue);
            this.Controls.Add(this.thetaValue);
            this.Controls.Add(this.phiValue);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.phiSlider);
            this.Controls.Add(this.thetaSlider);
            this.Controls.Add(this.psiSlider);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.altitudeSlider);
            this.Controls.Add(this.Altitude);
            this.Name = "Gyroscope";
            this.Text = "Gyroscope";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Gyroscope_FormClosed);
            this.Load += new System.EventHandler(this.Gyroscope_Load);
            ((System.ComponentModel.ISupportInitialize)(this.altitudeSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.psiSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thetaSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phiSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar altitudeSlider;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Altitude;
        private System.Windows.Forms.TrackBar psiSlider;
        private System.Windows.Forms.TrackBar thetaSlider;
        private System.Windows.Forms.TrackBar phiSlider;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox phiValue;
        private System.Windows.Forms.TextBox thetaValue;
        private System.Windows.Forms.TextBox psiValue;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
    }
}