﻿namespace TTC_GS_GUI.UserControles
{
    partial class Controller
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxAirSpeed = new System.Windows.Forms.GroupBox();
            this.labelAirSpeedMaxValue = new System.Windows.Forms.Label();
            this.labelAirSpeedMinValue = new System.Windows.Forms.Label();
            this.trackAirSpeedValue = new System.Windows.Forms.TrackBar();
            this.trackAltitudeValue = new System.Windows.Forms.TrackBar();
            this.labelAltitudeMinValue = new System.Windows.Forms.Label();
            this.labelAltitudeMaxValue = new System.Windows.Forms.Label();
            this.groupBoxAltitude = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.rtbLog = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.pfdWidget1 = new TTC_GS_GUI.UserControles.PFDWidget();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtMove = new System.Windows.Forms.TextBox();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Send = new System.Windows.Forms.Button();
            this.txtCommand = new System.Windows.Forms.TextBox();
            this.groupBoxAirSpeed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackAirSpeedValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackAltitudeValue)).BeginInit();
            this.groupBoxAltitude.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxAirSpeed
            // 
            this.groupBoxAirSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxAirSpeed.Controls.Add(this.labelAirSpeedMaxValue);
            this.groupBoxAirSpeed.Controls.Add(this.labelAirSpeedMinValue);
            this.groupBoxAirSpeed.Controls.Add(this.trackAirSpeedValue);
            this.groupBoxAirSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAirSpeed.ForeColor = System.Drawing.Color.Silver;
            this.groupBoxAirSpeed.Location = new System.Drawing.Point(3, 3);
            this.groupBoxAirSpeed.Name = "groupBoxAirSpeed";
            this.groupBoxAirSpeed.Size = new System.Drawing.Size(92, 72);
            this.groupBoxAirSpeed.TabIndex = 12;
            this.groupBoxAirSpeed.TabStop = false;
            this.groupBoxAirSpeed.Text = "Air Speed";
            // 
            // labelAirSpeedMaxValue
            // 
            this.labelAirSpeedMaxValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAirSpeedMaxValue.Location = new System.Drawing.Point(45, 49);
            this.labelAirSpeedMaxValue.Name = "labelAirSpeedMaxValue";
            this.labelAirSpeedMaxValue.Size = new System.Drawing.Size(31, 13);
            this.labelAirSpeedMaxValue.TabIndex = 7;
            this.labelAirSpeedMaxValue.Text = "20";
            this.labelAirSpeedMaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelAirSpeedMinValue
            // 
            this.labelAirSpeedMinValue.AutoSize = true;
            this.labelAirSpeedMinValue.Location = new System.Drawing.Point(14, 49);
            this.labelAirSpeedMinValue.Name = "labelAirSpeedMinValue";
            this.labelAirSpeedMinValue.Size = new System.Drawing.Size(13, 13);
            this.labelAirSpeedMinValue.TabIndex = 6;
            this.labelAirSpeedMinValue.Text = "0";
            // 
            // trackAirSpeedValue
            // 
            this.trackAirSpeedValue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackAirSpeedValue.Location = new System.Drawing.Point(6, 17);
            this.trackAirSpeedValue.Maximum = 20;
            this.trackAirSpeedValue.Name = "trackAirSpeedValue";
            this.trackAirSpeedValue.Size = new System.Drawing.Size(80, 45);
            this.trackAirSpeedValue.TabIndex = 5;
            this.trackAirSpeedValue.TickFrequency = 5;
            this.trackAirSpeedValue.Scroll += new System.EventHandler(this.trackAirSpeedValue_Scroll);
            //this.trackAirSpeedValue.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackAirSpeedValue_MouseUp);
            // 
            // trackAltitudeValue
            // 
            this.trackAltitudeValue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackAltitudeValue.Location = new System.Drawing.Point(6, 17);
            this.trackAltitudeValue.Maximum = 200;
            this.trackAltitudeValue.Name = "trackAltitudeValue";
            this.trackAltitudeValue.Size = new System.Drawing.Size(78, 45);
            this.trackAltitudeValue.TabIndex = 5;
            this.trackAltitudeValue.TickFrequency = 50;
            this.trackAltitudeValue.Scroll += new System.EventHandler(this.trackAltitudeValue_Scroll);
            //this.trackAltitudeValue.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackAltitudeValue_MouseUp);
            // 
            // labelAltitudeMinValue
            // 
            this.labelAltitudeMinValue.AutoSize = true;
            this.labelAltitudeMinValue.Location = new System.Drawing.Point(14, 49);
            this.labelAltitudeMinValue.Name = "labelAltitudeMinValue";
            this.labelAltitudeMinValue.Size = new System.Drawing.Size(13, 13);
            this.labelAltitudeMinValue.TabIndex = 6;
            this.labelAltitudeMinValue.Text = "0";
            // 
            // labelAltitudeMaxValue
            // 
            this.labelAltitudeMaxValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAltitudeMaxValue.Location = new System.Drawing.Point(43, 49);
            this.labelAltitudeMaxValue.Name = "labelAltitudeMaxValue";
            this.labelAltitudeMaxValue.Size = new System.Drawing.Size(31, 13);
            this.labelAltitudeMaxValue.TabIndex = 7;
            this.labelAltitudeMaxValue.Text = "200";
            this.labelAltitudeMaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBoxAltitude
            // 
            this.groupBoxAltitude.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxAltitude.Controls.Add(this.labelAltitudeMaxValue);
            this.groupBoxAltitude.Controls.Add(this.labelAltitudeMinValue);
            this.groupBoxAltitude.Controls.Add(this.trackAltitudeValue);
            this.groupBoxAltitude.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxAltitude.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAltitude.ForeColor = System.Drawing.Color.Silver;
            this.groupBoxAltitude.Location = new System.Drawing.Point(101, 3);
            this.groupBoxAltitude.Name = "groupBoxAltitude";
            this.groupBoxAltitude.Size = new System.Drawing.Size(93, 72);
            this.groupBoxAltitude.TabIndex = 11;
            this.groupBoxAltitude.TabStop = false;
            this.groupBoxAltitude.Text = "Altitude";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.11227F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.81984F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.06788F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.17027F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(766, 417);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.rtbLog, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.17518F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.82482F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(217, 411);
            this.tableLayoutPanel2.TabIndex = 15;
            // 
            // cameraWidget1
            // 
            //this.cameraWidget1.Dock = System.Windows.Forms.DockStyle.Fill;
            //this.cameraWidget1.Location = new System.Drawing.Point(3, 3);
            //this.cameraWidget1.Name = "cameraWidget1";
            //this.cameraWidget1.Size = new System.Drawing.Size(211, 191);
            //this.cameraWidget1.TabIndex = 0;
            // 
            // rtbLog
            // 
            this.rtbLog.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.rtbLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbLog.ForeColor = System.Drawing.Color.LightGray;
            this.rtbLog.Location = new System.Drawing.Point(3, 200);
            this.rtbLog.Name = "rtbLog";
            this.rtbLog.ReadOnly = true;
            this.rtbLog.Size = new System.Drawing.Size(211, 208);
            this.rtbLog.TabIndex = 1;
            this.rtbLog.Text = "";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.pfdWidget1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(554, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(209, 411);
            this.tableLayoutPanel3.TabIndex = 16;
            // 
            // pfdWidget1
            // 
            this.pfdWidget1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pfdWidget1.Location = new System.Drawing.Point(3, 3);
            this.pfdWidget1.Name = "pfdWidget1";
            this.pfdWidget1.Size = new System.Drawing.Size(203, 199);
            this.pfdWidget1.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 208);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 85F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(203, 200);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.groupBoxAltitude, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.groupBoxAirSpeed, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(197, 79);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtMove);
            this.panel1.Controls.Add(this.btn_Clear);
            this.panel1.Controls.Add(this.btn_Send);
            this.panel1.Controls.Add(this.txtCommand);
            //this.panel1.Controls.Add(this.MouseStick);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 88);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 109);
            this.panel1.TabIndex = 1;
            // 
            // txtMove
            // 
            this.txtMove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMove.Location = new System.Drawing.Point(107, 86);
            this.txtMove.Name = "txtMove";
            this.txtMove.Size = new System.Drawing.Size(87, 20);
            this.txtMove.TabIndex = 5;
            // 
            // btn_Clear
            // 
            this.btn_Clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Clear.Location = new System.Drawing.Point(107, 59);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(87, 23);
            this.btn_Clear.TabIndex = 4;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            //this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Send
            // 
            this.btn_Send.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Send.Location = new System.Drawing.Point(107, 30);
            this.btn_Send.Name = "btn_Send";
            this.btn_Send.Size = new System.Drawing.Size(87, 23);
            this.btn_Send.TabIndex = 3;
            this.btn_Send.Text = "Send";
            this.btn_Send.UseVisualStyleBackColor = true;
            //this.btn_Send.Click += new System.EventHandler(this.btn_Send_Click);
            // 
            // txtCommand
            // 
            this.txtCommand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCommand.Location = new System.Drawing.Point(107, 3);
            this.txtCommand.Name = "txtCommand";
            this.txtCommand.Size = new System.Drawing.Size(87, 20);
            this.txtCommand.TabIndex = 2;
            // 
            // MouseStick
            // 
            //this.MouseStick.AllowDrop = true;
            //this.MouseStick.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            //| System.Windows.Forms.AnchorStyles.Left) 
            //| System.Windows.Forms.AnchorStyles.Right)));
            //this.MouseStick.BackColor = System.Drawing.SystemColors.WindowFrame;
            //this.MouseStick.Cursor = System.Windows.Forms.Cursors.Cross;
            //this.MouseStick.LineEnd = System.Drawing.Drawing2D.LineCap.Round;
            //this.MouseStick.Location = new System.Drawing.Point(3, 3);
            //this.MouseStick.Name = "MouseStick";
            //this.MouseStick.NeedleColor = System.Drawing.Color.Yellow;
            //this.MouseStick.NeedleWidth = 2;
            //this.MouseStick.Size = new System.Drawing.Size(103, 105);
            //this.MouseStick.TabIndex = 1;
            //this.MouseStick.Text = "MouseStick";
            //this.MouseStick.MouseStickMoved += new NSMouseStick.MouseStickMovedEventHandler(this.MouseStick_MouseStickMoved);
            //this.MouseStick.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.MouseStick_MouseDoubleClick);
            // 
            // mapWidget1
            // 
            //this.mapWidget1.Dock = System.Windows.Forms.DockStyle.Fill;
            //this.mapWidget1.Location = new System.Drawing.Point(226, 3);
            //this.mapWidget1.Name = "mapWidget1";
            //this.mapWidget1.Size = new System.Drawing.Size(322, 411);
            //this.mapWidget1.TabIndex = 17;
            //this.mapWidget1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.mapWidget1_MouseDoubleClick);
            // 
            // Controller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Controller";
            this.Size = new System.Drawing.Size(766, 417);
            //this.Load += new System.EventHandler(this.Controller_Load);
            this.groupBoxAirSpeed.ResumeLayout(false);
            this.groupBoxAirSpeed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackAirSpeedValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackAltitudeValue)).EndInit();
            this.groupBoxAltitude.ResumeLayout(false);
            this.groupBoxAltitude.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxAirSpeed;
        private System.Windows.Forms.Label labelAirSpeedMaxValue;
        private System.Windows.Forms.Label labelAirSpeedMinValue;
        private System.Windows.Forms.TrackBar trackAirSpeedValue;
        private System.Windows.Forms.TrackBar trackAltitudeValue;
        private System.Windows.Forms.Label labelAltitudeMinValue;
        private System.Windows.Forms.Label labelAltitudeMaxValue;
        private System.Windows.Forms.GroupBox groupBoxAltitude;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private PFDWidget pfdWidget1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox rtbLog;
        private System.Windows.Forms.TextBox txtMove;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Send;
        private System.Windows.Forms.TextBox txtCommand;
    }
}
