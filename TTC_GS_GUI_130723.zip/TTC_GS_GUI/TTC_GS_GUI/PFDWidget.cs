﻿using TTC_GS_GUI.Indicators;
using System;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace TTC_GS_GUI.UserControles
{
    public partial class PFDWidget :
        UserControl,
        IPrimaryFlightDisplay
    {
        /// <summary>
        /// Air Speed.</summary>
        private VerticalIndicator airspeed = new VerticalIndicator();

        /// <summary>
        /// Altitude Gauge.</summary>
        private VerticalIndicator altitude = new VerticalIndicator();

        /// <summary>
        /// Compass.</summary>
        private HeadingIndicator heading = new HeadingIndicator();

        /// <summary>
        /// Artificial Horizon.</summary>
        private AttitudeIndicator attitudeIndicator = new AttitudeIndicator();

        /// <summary>
        /// Air Speed Indicator.</summary>
        public IIndicator AirSpeed
        {
            get { return airspeed; }
        }

        /// <summary>
        /// Altitude Indicator.</summary>
        public IIndicator Altitude
        {
            get { return altitude; }
        }

        /// <summary>
        /// Heading Indicator.</summary>
        public IIndicator Heading
        {
            get { return heading; }
        }

        /// <summary>
        /// Attitude Indicator.</summary>
        public IAttitudeIndicator AttitudeIndicator
        {
            get { return attitudeIndicator; }
        }

        /// <summary>
        /// Class Constructor.
        /// </summary>
        public PFDWidget()
        {
            InitializeComponent();

            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);

            //InitializeGauges();
        }

        /// <summary>
        /// Initialize Gauges.</summary>
        //protected void InitializeGauges()
        //{
        //    altitude.Orientation = IndicatorOrientation.Right;
        //    //altitude.MinimumValue = 0;
        //    altitude.MinimumValue = Properties.Settings.Default.MinAlt;
        //    //altitude.MaximumValue = 200;
        //    altitude.MaximumValue = Properties.Settings.Default.MaxAlt;
        //    altitude.MajorScaleGraduation = 20;

        //    airspeed.Orientation = IndicatorOrientation.Left;
        //    //airspeed.MinimumValue = 0;
        //    airspeed.MinimumValue = Properties.Settings.Default.MinSpeed;
        //    //airspeed.MaximumValue = 20;
        //    airspeed.MaximumValue = Properties.Settings.Default.MaxSpeed;

        //    if (Configuration.sport != null)
        //    {
        //        if (Configuration.sport.IsOpen)
        //            Configuration.sport.DataReceived += new SerialDataReceivedEventHandler(sport_DataReceived);
        //    }
        //}


        delegate void SetValueDelegate(string value, string roll);
        public void SetValue(string pitch, string roll)
        {
            try
            {
                if (InvokeRequired)
                    Invoke(new SetValueDelegate(SetValue), pitch, roll);
                else
                {
                    IPrimaryFlightDisplay pfd = this as IPrimaryFlightDisplay;

                    //float r = float.Parse(roll);
                    //if (r < pfd.AttitudeIndicator.RollAngle)
                    //    pfd.AttitudeIndicator.RollAngle--;
                    //else if (r > pfd.AttitudeIndicator.RollAngle)
                    //    pfd.AttitudeIndicator.RollAngle++;
                    //else
                    //    pfd.AttitudeIndicator.RollAngle = r;

                    //float p = float.Parse(pitch);
                    //if (p < pfd.AttitudeIndicator.PitchAngle)
                    //    pfd.AttitudeIndicator.PitchAngle--;
                    //else if (p > pfd.AttitudeIndicator.PitchAngle)
                    //    pfd.AttitudeIndicator.PitchAngle++;
                    //else
                    //    pfd.AttitudeIndicator.PitchAngle = p;

                    pfd.AttitudeIndicator.RollAngle = float.Parse(roll);
                    pfd.AttitudeIndicator.PitchAngle = float.Parse(pitch);

                    SetText("Pitch: " + pitch + ", Roll: " + roll);

                    this.Update(); this.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        delegate void SetTextDelegate(string value);
        public void SetText(string value)
        {
            if (InvokeRequired)
                Invoke(new SetTextDelegate(SetText), value);
            else
            {
                lbInfo.Text = value + "\n";
            }
        }

        /// <summary>
        /// Redraw User Control.</summary>
        public void Redraw()
        {
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);
        }

        private void GraphicUserControl_Resize(object sender, EventArgs e)
        {
            attitudeIndicator.SetDrawingEnvelope(this.DisplayRectangle);

            Rectangle altitudeRect = new Rectangle();

            altitudeRect.Height = 300;
            altitudeRect.Width = 60;
            altitudeRect.Y = (this.Height - altitudeRect.Height) / 2;
            altitudeRect.X = (this.Width - altitudeRect.Width - 20);

            altitude.SetDrawingEnvelope(altitudeRect);

            Rectangle airspeedRect = new Rectangle();

            airspeedRect.Height = 300;
            airspeedRect.Width = 60;
            airspeedRect.Y = (this.Height - airspeedRect.Height) / 2;
            airspeedRect.X = 20;

            airspeed.SetDrawingEnvelope(airspeedRect);

            Rectangle compassRect = new Rectangle();

            compassRect.Width = 250;
            compassRect.Height = 40;
            compassRect.Y = (this.Bottom - compassRect.Height - 20);
            compassRect.X = (this.Right - compassRect.Width) / 2;

            heading.SetDrawingEnvelope(compassRect);

            Redraw();
        }

        private void GraphicUserControl_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            attitudeIndicator.Draw(g);
            airspeed.Draw(g);
            altitude.Draw(g);
            heading.Draw(g);
        }

        private void GraphicUserControl_MouseDown(object sender, MouseEventArgs e)
        {
        }

        private void GraphicUserControl_MouseUp(object sender, MouseEventArgs e)
        {
        }

        private void GraphicUserControl_MouseMove(object sender, MouseEventArgs e)
        {
        }
    }
}
