﻿using System.Drawing;

namespace TTC_GS_GUI.Indicators
{
    /// <summary>
    /// Heading Indicator.</summary>
    public class HeadingIndicator : Indicator
    {
        /// <summary>
        /// New Drawing Envelope received.</summary>
        protected override void NewDrawingEnvelopeReceived()
        {
        }

        /// <summary>
        /// Draw Function.</summary>
        /// <param name="g">Graphics for Drawing</param>
        public override void Draw(Graphics g)
        {

        }
    }
}
