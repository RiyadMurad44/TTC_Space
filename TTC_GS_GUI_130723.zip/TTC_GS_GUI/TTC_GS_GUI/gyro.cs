﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TTC_GS_GUI
{
    public partial class gyro : Form
    {

        Stateform sf;

        public gyro()
        {
            InitializeComponent();
        }

        public gyro(Stateform sf)
        {
            InitializeComponent();
            this.sf = sf;
        }

        //private void trackAltitudeValue(object sender, EventArgs e)
        //{
        //    UpdateAltitudeGaugeParams();
        //}

        //private void trackAirSpeedValue(object sender, EventArgs e)
        //{
        //    UpdateAltitudeGaugeParams();
        //}

        //private void gyro_Load(object sender, EventArgs e)
        //{
        //    IPrimaryFlightDisplay pfd = pfdWidget1 as IPrimaryFlightDisplay;

        //    pfd.Altitude.Value = 
        //    pfd.AirSpeed.Value = 

        //    pfdWidget1.Redraw();
        //}

        //void UpdateAltitudeGaugeParams()
        //{
        //    IPrimaryFlightDisplay pfd = pfdWidget1 as IPrimaryFlightDisplay;

        //    pfd.Altitude.Value = trackAltitudeValue.Value;
        //    pfd.AirSpeed.Value = trackAirSpeedValue.Value;

        //    pfdWidget1.Redraw();
        //}

    }
}
