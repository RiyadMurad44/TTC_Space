﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Timers;

namespace TTC_GS_GUI
{
    public partial class ttcForm : Form
    {
        Stateform sf;

        public ttcForm(Stateform sf)
        {
            InitializeComponent();
            this.sf = sf;
            sf.receivedData = new StringBuilder();            
        }

        private void ttcForm_Load(object sender, EventArgs e)
        {
            // Create a new SerialPort object
            foreach (String s in SerialPort.GetPortNames())
            {
                //Adding the available ports to the combo box
                AvailablePorts.Items.Add(s);
            }

            string folderPath = @"..\..\..\Images";
            sf.setImageFiles(Directory.GetFiles(folderPath));

            // Load the initial image
            LoadImage();

            // Start the timer
            timer1.Start();
        }

        public void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            //Read the data from the serial port
            if(sf.getIsConnected() == true && sf.getContinueReading() == true)
            {
                try
                {
                    string data = sf.serialPort.ReadLine();
                    sf.receivedData.Append(data);

                    ProcessReceivedData();
                    //await ProcessReceivedData();
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }

        }

        private void ProcessReceivedData()
        {
            Thread gyroThread = null;
            try
            {
                gyroThread = new Thread(() =>
                {
                    string[] lines = sf.receivedData.ToString().Split(' ');

                    foreach (string line in lines)
                    {
                        string[] values = line.Split(',');
                        if (values.Length > 23)
                        {
                            Invoke(new Action(() =>
                            {
                                battery_voltage.Text = values[0];
                                current_value.Text = values[1];
                                sun_exposure.Text = values[2];
                                temperature.Text = values[3];

                                acceleration_x.Text = values[4];
                                acceleration_y.Text = values[5];
                                acceleration_z.Text = values[6];

                                angular_rate_phi.Text = values[7];
                                angular_rate_theta.Text = values[8];
                                angular_rate_psi.Text = values[9];

                                angles_theta.Text = values[10];
                                angles_phi.Text = values[11];
                                angles_psi.Text = values[12];

                                position_x.Text = values[13];
                                position_y.Text = values[14];
                                position_z.Text = values[15];

                                software_version.Text = values[16];
                                cube_sat_id.Text = values[17];
                                radio_status.Text = values[18];
                                battery_status.Text = values[19];

                                valve_1.Text = values[20];
                                valve_2.Text = values[21];
                                valve_3.Text = values[22];
                                valve_4.Text = values[23];
                            }));
                            sf.setGyroTheta(double.Parse(values[10]));
                            sf.setGyroPhi(double.Parse(values[11]));
                            sf.setGyroPsi(double.Parse(values[12]));
                            sf.setAltitude(double.Parse(values[15]));
                        }
                    }
                    sf.receivedData.Clear();
                });
                gyroThread.Start();
            }
            catch (Exception)
            {
                gyroThread.Suspend();
            }
            finally
            {

            }
        }

        private async void Start_Click(object sender, EventArgs e)
        {
            string sp = AvailablePorts.SelectedItem as string;
            sf.setCount(sf.getCount() + 1);

            if (sf.getCount() == 2 && sf.getIsConnected() == true)
            {
                AvailablePorts.SelectedIndexChanged += AvailablePorts_SelectedIndexChanged;
            }

            while (sf.getIsConnected() == false)
            {
                try
                {
                    sf.serialPort = new SerialPort(sp, 9600);
                    // Set the data received event handler
                    sf.serialPort.DataReceived += serialPort_DataReceived;
                    sf.serialPort.Open();
                    sf.setIsConnected(true);
                }
                catch (Exception ex)
                {
                    await ShowErrorMessageAsync(ex.Message);
                    break;
                }
            }

        }

        private void Stop_Click(object sender, EventArgs e)
        {
            sf.serialPort.DataReceived -= serialPort_DataReceived;
            if (sf.getIsConnected() == true)
            {
                sf.setContinueReading(false);
                sf.serialPort.Close();
                sf.setIsConnected(false);
                sf.setCount(0);

            }
        }

        private void LoadImage()
        {
            string imagePath = sf.imageFiles[sf.currentImageIndex];
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            sf.setCurrentImageIndex(sf.getCurrentImageIndex() + 1);
            if (sf.getCurrentImageIndex() >= sf.imageFiles.Length)
            {
                sf.setCurrentImageIndex(0);
            }

            LoadImage();
        }

        private async Task ShowErrorMessageAsync(string message)
        {
            await Task.Yield();
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void AvailablePorts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(sf.getCount() == 2)
            {
                MessageBox.Show("Code is ruuning! Please stop the process before changing the port", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Gyro_Click(object sender, EventArgs e)
        {
            
            if (!sf.getIsGyroOpened())
            {
                Thread gyroThread = new Thread(() =>
                {
                    Application.Run(new Gyroscope(sf));
                });
                sf.setIsGyroOpened(true);
                gyroThread.Start();
            }
        }
    }
}
