﻿namespace TTC_GS_GUI
{
    partial class Gyroscope
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.altitudeSlider = new System.Windows.Forms.TrackBar();
            this.Altitude = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.psiSlider = new System.Windows.Forms.TrackBar();
            this.thetaSlider = new System.Windows.Forms.TrackBar();
            this.phiSlider = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.phiValue = new System.Windows.Forms.TextBox();
            this.thetaValue = new System.Windows.Forms.TextBox();
            this.psiValue = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.altitudeSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.psiSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thetaSlider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phiSlider)).BeginInit();
            this.SuspendLayout();
            // 
            // altitudeSlider
            // 
            this.altitudeSlider.BackColor = System.Drawing.Color.White;
            this.altitudeSlider.Enabled = false;
            this.altitudeSlider.Location = new System.Drawing.Point(584, 43);
            this.altitudeSlider.Maximum = 1000;
            this.altitudeSlider.Name = "altitudeSlider";
            this.altitudeSlider.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.altitudeSlider.Size = new System.Drawing.Size(45, 455);
            this.altitudeSlider.TabIndex = 1;
            this.altitudeSlider.TickStyle = System.Windows.Forms.TickStyle.Both;
            // 
            // Altitude
            // 
            this.Altitude.Enabled = false;
            this.Altitude.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Altitude.Location = new System.Drawing.Point(562, 503);
            this.Altitude.Margin = new System.Windows.Forms.Padding(2);
            this.Altitude.Multiline = true;
            this.Altitude.Name = "Altitude";
            this.Altitude.Size = new System.Drawing.Size(89, 45);
            this.Altitude.TabIndex = 148;
            this.Altitude.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Altitude.TextChanged += new System.EventHandler(this.Altitude_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(570, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 24);
            this.label1.TabIndex = 149;
            this.label1.Text = "Altitude";
            // 
            // psiSlider
            // 
            this.psiSlider.BackColor = System.Drawing.Color.White;
            this.psiSlider.Enabled = false;
            this.psiSlider.Location = new System.Drawing.Point(653, 403);
            this.psiSlider.Maximum = 60;
            this.psiSlider.Name = "psiSlider";
            this.psiSlider.Size = new System.Drawing.Size(231, 45);
            this.psiSlider.TabIndex = 151;
            // 
            // thetaSlider
            // 
            this.thetaSlider.BackColor = System.Drawing.Color.White;
            this.thetaSlider.Enabled = false;
            this.thetaSlider.Location = new System.Drawing.Point(653, 255);
            this.thetaSlider.Maximum = 60;
            this.thetaSlider.Name = "thetaSlider";
            this.thetaSlider.Size = new System.Drawing.Size(231, 45);
            this.thetaSlider.TabIndex = 152;
            // 
            // phiSlider
            // 
            this.phiSlider.BackColor = System.Drawing.Color.White;
            this.phiSlider.Enabled = false;
            this.phiSlider.Location = new System.Drawing.Point(653, 107);
            this.phiSlider.Maximum = 60;
            this.phiSlider.Name = "phiSlider";
            this.phiSlider.Size = new System.Drawing.Size(231, 45);
            this.phiSlider.TabIndex = 153;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(660, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 24);
            this.label3.TabIndex = 154;
            this.label3.Text = "Angle Phi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(660, 219);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 24);
            this.label4.TabIndex = 155;
            this.label4.Text = "Angle Theta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(660, 366);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 24);
            this.label5.TabIndex = 156;
            this.label5.Text = "Angle Psi";
            // 
            // phiValue
            // 
            this.phiValue.Enabled = false;
            this.phiValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phiValue.Location = new System.Drawing.Point(889, 107);
            this.phiValue.Margin = new System.Windows.Forms.Padding(2);
            this.phiValue.Multiline = true;
            this.phiValue.Name = "phiValue";
            this.phiValue.Size = new System.Drawing.Size(89, 45);
            this.phiValue.TabIndex = 157;
            this.phiValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // thetaValue
            // 
            this.thetaValue.Enabled = false;
            this.thetaValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thetaValue.Location = new System.Drawing.Point(889, 255);
            this.thetaValue.Margin = new System.Windows.Forms.Padding(2);
            this.thetaValue.Multiline = true;
            this.thetaValue.Name = "thetaValue";
            this.thetaValue.Size = new System.Drawing.Size(89, 45);
            this.thetaValue.TabIndex = 158;
            this.thetaValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // psiValue
            // 
            this.psiValue.Enabled = false;
            this.psiValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.psiValue.Location = new System.Drawing.Point(889, 403);
            this.psiValue.Margin = new System.Windows.Forms.Padding(2);
            this.psiValue.Multiline = true;
            this.psiValue.Name = "psiValue";
            this.psiValue.Size = new System.Drawing.Size(89, 45);
            this.psiValue.TabIndex = 159;
            this.psiValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Gyroscope
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 611);
            this.Controls.Add(this.psiValue);
            this.Controls.Add(this.thetaValue);
            this.Controls.Add(this.phiValue);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.phiSlider);
            this.Controls.Add(this.thetaSlider);
            this.Controls.Add(this.psiSlider);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.altitudeSlider);
            this.Controls.Add(this.Altitude);
            this.Name = "Gyroscope";
            this.Text = "Gyroscope";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Gyroscope_FormClosed);
            this.Load += new System.EventHandler(this.Gyroscope_Load);
            ((System.ComponentModel.ISupportInitialize)(this.altitudeSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.psiSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thetaSlider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phiSlider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar altitudeSlider;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Altitude;
        private System.Windows.Forms.TrackBar psiSlider;
        private System.Windows.Forms.TrackBar thetaSlider;
        private System.Windows.Forms.TrackBar phiSlider;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox phiValue;
        private System.Windows.Forms.TextBox thetaValue;
        private System.Windows.Forms.TextBox psiValue;
    }
}