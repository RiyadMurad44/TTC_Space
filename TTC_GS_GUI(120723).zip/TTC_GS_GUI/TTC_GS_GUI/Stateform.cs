﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TTC_GS_GUI
{
    public class Stateform
    {
        public Stateform() { }

        public SerialPort serialPort;
        public StringBuilder receivedData;

        public int currentImageIndex = 0;
        public string[] imageFiles;
        public static bool connected = false;
        private static bool continueReading = true;
        private static bool IsGyroOpened = false;
        public static int count = 0;

        public double gyroPhi, gyroTheta, gyroPsi, altitude;

        public int getCurrentImageIndex()
        {
            return currentImageIndex;
        }

        public string[] getImageFiles() {
            return imageFiles;
        }

        public bool getIsConnected()
        {
            return connected;
        }

        public int getCount()
        {
            return count;
        }

        public bool getContinueReading()
        {
            return continueReading;
        }

        public double getGyroPhi()
        {
            return gyroPhi;
        }

        public double getGyroTheta()
        {
            return gyroTheta;
        }

        public double getGyroPsi()
        {
            return gyroPsi;
        }

        public double getAltitude()
        {
            return altitude;
        }

        public bool getIsGyroOpened()
        {
            return IsGyroOpened;
        }

        public void setCurrentImageIndex(int index)
        {
            currentImageIndex = index;
        }

        public void setCount(int c)
        {
            count = c;
        }

        public void setIsConnected(bool con)
        {
            connected = con;
        }

        public void setImageFiles(string[] files)
        {
            imageFiles = files;
        }

        public void setContinueReading(bool con)
        {
            continueReading = con;
        }

        public void setGyroPhi(double gyroPh)
        {
            gyroPhi = gyroPh;
        }

        public void setGyroTheta(double gyroTh)
        {
            gyroTheta = gyroTh;
        }

        public void setGyroPsi(double gyroPs)
        {
            gyroPsi = gyroPs;
        }

        public void setAltitude(double al)
        {
            altitude = al;
        }

        public void setIsGyroOpened(bool isG)
        {
            IsGyroOpened = isG;
        }
    }
}
